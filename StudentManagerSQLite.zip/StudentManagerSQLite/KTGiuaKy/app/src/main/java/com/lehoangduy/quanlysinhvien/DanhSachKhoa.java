package com.lehoangduy.quanlysinhvien;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.Activity.MainActivity;

import com.lehoangduy.quanlysinhvien.Activity.QuanLySinhVien;
import com.lehoangduy.quanlysinhvien.Activity.ThemKhoa;
import com.lehoangduy.quanlysinhvien.Adapter.KhoaDanhSachAdapter;
import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;

import java.util.ArrayList;

public class DanhSachKhoa extends AppCompatActivity {

    ListView lvDSKhoa;
    ArrayList<Khoa> arrKhoa;
    ArrayList<SinhVien> arrSinhVien;
    KhoaDanhSachAdapter adapterKhoa;
    String maDel = "";
    int vitri = 0;
    String masv = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_khoa);
        lvDSKhoa = (ListView) findViewById(R.id.listViewDanhSachKhoa);
        arrKhoa = new ArrayList<>();
        arrSinhVien = new ArrayList<>();
        GetKhoa();


        lvDSKhoa.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                vitri = position;
                maDel = arrKhoa.get(position).MaKhoa;
                masv = maDel;
                return false;
            }
        });

        registerForContextMenu(lvDSKhoa);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(1, 111, 1, R.string.themmoi);
        menu.add(1, 222, 2, R.string.quaylai);
        menu.add(1, 333, 3, R.string.dangxuat);
        menu.add(1, 444, 4, R.string.exit);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case 111:
                Intent intent = new Intent(DanhSachKhoa.this, ThemKhoa.class);
                startActivity(intent);
                break;
            case 222:
                finish();
                Intent intent1 = new Intent(DanhSachKhoa.this, QuanLySinhVien.class);
                startActivity(intent1);
                break;
            case 333:
               // finish();
                Intent intent2 = new Intent(DanhSachKhoa.this, MainActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent2);
                final SharedPreferences preferences = getSharedPreferences("data_login", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("checked", true);
                editor.clear();
                editor.commit();
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                break;
            case 444:
                android.support.v7.app.AlertDialog.Builder alertDialogBuilder = new android.support.v7.app.AlertDialog.Builder(DanhSachKhoa.this);
                alertDialogBuilder.setTitle("Exit Application?");
                alertDialogBuilder.setIcon(R.mipmap.ic_launcher);
                alertDialogBuilder
                        .setMessage("Click yes to exit!")
                        .setCancelable(false)
                        .setPositiveButton("Yes",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        intent.putExtra("EXIT", true);
                                        startActivity(intent);
                                    }
                                })

                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.cancel();
                            }
                        });

                android.support.v7.app.AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.add(1, 111, 1, R.string.xemdanhsachsv);
        menu.add(1, 222, 2, R.string.xoakhoanay);
        menu.add(1, 333, 3, R.string.suathongtin);

        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case 111:
                Intent intentDS = new Intent(DanhSachKhoa.this, DanhSachSVCuaKhoa.class);
                intentDS.putExtra("masvofkhoa", arrKhoa.get(vitri).MaKhoa);
                startActivity(intentDS);
                break;
            case 222:
                        Cursor cursor = MainActivity.db.GetData("SELECT * FROM SinhVien_Table WHERE MaKhoa = '"+maDel+"'");
                        if (cursor!=null) {
                            while (cursor.moveToNext()){
                                arrSinhVien.add(new SinhVien(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getBlob(3), cursor.getString(4), cursor.getString(5), cursor.getString(6)));
                            }

                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setTitle(R.string.xndelete);
                            builder.setMessage(R.string.comunxoa);
                            builder.setIcon(R.mipmap.ic_launcher_delete);
                            builder.setCancelable(false);
                            builder.setPositiveButton(R.string.co, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if(arrSinhVien.size()==0){
                                        MainActivity.db.DELETE_KHOA(maDel);
                                        Toast.makeText(DanhSachKhoa.this, R.string.xoathanhcong, Toast.LENGTH_SHORT).show();
                                        arrKhoa.clear();
                                        GetKhoa();
                                    }else{
                                        Toast.makeText(DanhSachKhoa.this, getString(R.string.kthexoavi)+arrSinhVien.size()+getString(R.string.student), Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                            builder.setNegativeButton(R.string.khong, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                            builder.show();


                        }

                break;
            case 333:
                Intent intent = new Intent(DanhSachKhoa.this, ThemKhoa.class);
                intent.putExtra("makhoa", arrKhoa.get(vitri).MaKhoa);
                startActivity(intent);
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void GetKhoa(){
        Cursor getkhoa = MainActivity.db.GetData("SELECT * FROM Khoa_Table");
        while (getkhoa.moveToNext()){
            arrKhoa.add(new Khoa(getkhoa.getString(0), getkhoa.getString(1)));
        }
        adapterKhoa = new KhoaDanhSachAdapter(this, R.layout.dong_khoa, arrKhoa);
        lvDSKhoa.setAdapter(adapterKhoa);
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent intent = new Intent(DanhSachKhoa.this, QuanLySinhVien.class);
        startActivity(intent);
        super.onBackPressed();
    }
}
