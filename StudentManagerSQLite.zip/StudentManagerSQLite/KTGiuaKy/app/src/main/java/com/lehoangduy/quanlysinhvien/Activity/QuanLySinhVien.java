package com.lehoangduy.quanlysinhvien.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.lehoangduy.ktgiuaky.R;
import com.lehoangduy.quanlysinhvien.DanhSachKhoa;
import com.lehoangduy.quanlysinhvien.DanhSachSV;

import static com.lehoangduy.ktgiuaky.R.id.btnInternet;

public class QuanLySinhVien extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ImageButton btnAddSV, btnAddPB, btnMusic, btnFile;
    private Boolean exit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quan_ly_sinh_vien);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        AnhXa();
        AddEvent();

        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setBackgroundColor(Color.DKGRAY);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (exit) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("EXIT", true);
                startActivity(intent);
            } else {
                Toast.makeText(this, R.string.anback, Toast.LENGTH_SHORT).show();
                exit = true;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        exit = false;
                    }
                }, 3 * 1000);

            }
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_Logout) {
            Intent intent = new Intent(QuanLySinhVien.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            final SharedPreferences preferences = getSharedPreferences("data_login", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("checked", true);
            editor.clear();
            editor.commit();
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else if (id == R.id.nav_SinhVien) {
            finish();
            Intent intent1 = new Intent(QuanLySinhVien.this, DanhSachSV.class);
            startActivity(intent1);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        } else if (id == R.id.nav_Phongban) {
            finish();
            Intent intent2 = new Intent(QuanLySinhVien.this, DanhSachKhoa.class);
            startActivity(intent2);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } else if (id == R.id.nav_Maps) {
            Intent intent4 = new Intent(QuanLySinhVien.this, MapsActivity.class);
            startActivity(intent4);
            overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
        } else if (id == R.id.nav_Help) {
            Intent intent3 = new Intent(QuanLySinhVien.this, Help.class);
            startActivity(intent3);
            overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
        } else if (id == R.id.nav_Exit) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(QuanLySinhVien.this);
            alertDialogBuilder.setTitle(R.string.thoatapp);
            alertDialogBuilder.setIcon(R.mipmap.ic_launcher);
            alertDialogBuilder
                    .setMessage(R.string.yes)
                    .setCancelable(false)
                    .setPositiveButton(R.string.cccc,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(QuanLySinhVien.this, MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    intent.putExtra("EXIT", true);
                                    startActivity(intent);
                                }
                            })

                    .setNegativeButton(R.string.kkk, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                            dialog.cancel();
                        }
                    });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void AnhXa(){

        btnAddSV = (ImageButton) findViewById(btnInternet);
        btnAddPB    = (ImageButton) findViewById(R.id.btnMail);
        btnMusic    = (ImageButton) findViewById(R.id.btnMusic);
        btnFile     = (ImageButton) findViewById(R.id.btnFile);
    }
    private void AddEvent(){
        btnAddSV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLySinhVien.this, ThemSinhVien.class);
                startActivity(intent);
                overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });
        btnAddPB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLySinhVien.this, ThemKhoa.class);
                startActivity(intent);
                overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });
        btnMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent music = new Intent(MediaStore.INTENT_ACTION_MUSIC_PLAYER);
                music.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(music);
                overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });
        btnFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent file = new Intent(Intent.ACTION_GET_CONTENT);
                file.setType("file/*");
                startActivity(file);
                overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });
    }
}
