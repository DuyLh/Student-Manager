package com.lehoangduy.quanlysinhvien;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.lehoangduy.quanlysinhvien.Activity.ChiTietSinhVien;
import com.lehoangduy.quanlysinhvien.Activity.QuanLySinhVien;
import com.lehoangduy.quanlysinhvien.Fragment.FragmentSVChiTiet;
import com.lehoangduy.quanlysinhvien.Fragment.SendSVDetail;
import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;


public class DanhSachSV extends AppCompatActivity implements SendSVDetail {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_sv);
    }

    @Override
    public void NhanSV(SinhVien sv) {
        FragmentSVChiTiet chiTiet = (FragmentSVChiTiet) getFragmentManager().findFragmentById(R.id.fragmenSVDetail);
        Configuration configuration = getResources().getConfiguration();
        if(chiTiet!=null && configuration.orientation == configuration.ORIENTATION_LANDSCAPE){
            chiTiet.SetText(sv);
        }else{
            Intent intent = new Intent(DanhSachSV.this, ChiTietSinhVien.class);
            intent.putExtra("masv", sv.MaSinhVien);
            startActivity(intent);

        }
    }
    @Override
    public void onBackPressed() {
        finish();
        Intent intent = new Intent(DanhSachSV.this, QuanLySinhVien.class);
        startActivity(intent);
        super.onBackPressed();
    }
}
