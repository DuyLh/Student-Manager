package com.lehoangduy.quanlysinhvien.Fragment;

import android.app.AlertDialog;
import android.app.ListFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.Activity.MainActivity;
import com.lehoangduy.quanlysinhvien.Activity.QuanLySinhVien;
import com.lehoangduy.quanlysinhvien.Activity.ThemSinhVien;
import com.lehoangduy.quanlysinhvien.Activity.UpdateSinhVien;
import com.lehoangduy.quanlysinhvien.Adapter.SinhVienAdapter;
import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class FragmentListSV extends ListFragment {
    FloatingActionButton fab, fabPlus, fabBack, fabLogout;
    Animation animation;
    Boolean showhide = false;
    ArrayList<SinhVien> arrSinhVien;
    ArrayList<Khoa> arrKhoa;
    SinhVienAdapter adapter = null;
    SendSVDetail sendSV;
    View view;
    String maDel = "";
    int vitri = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragmen_list_sv, container, false);
        AnhXa();
        GetSinhVien();
        GetKhoa();
        XuLy();
        fab.setAnimation(animation);


        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        registerForContextMenu(this.getListView());

        getListView().setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                vitri = position;
                maDel = arrSinhVien.get(position).MaSinhVien;
                return false;
            }
        });

        Configuration configuration = getResources().getConfiguration();

        if(configuration.orientation == configuration.ORIENTATION_LANDSCAPE) {
            fab.hide();
            sendSV.NhanSV(arrSinhVien.get(0));
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        sendSV.NhanSV(arrSinhVien.get(position));

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.add(1, 111, 1, R.string.suathongtinsv);
        menu.add(1, 222, 2, R.string.det);

        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case 111:
                getActivity().getFragmentManager().popBackStack();
                Intent intent = new Intent(getActivity(), UpdateSinhVien.class);
                Bundle bundle = new Bundle();
                bundle.putString("maKhoa", arrSinhVien.get(vitri).MaKhoa);
                bundle.putString("maupdate", arrSinhVien.get(vitri).MaSinhVien);
                intent.putExtra("data", bundle);
                startActivity(intent);
                break;
            case 222:
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle(R.string.xachanxoasv);
                builder.setIcon(R.mipmap.ic_launcher_delete);
                builder.setMessage(R.string.xoanha);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.c, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.db.DELETE_SINHVIEN(maDel);
                        Toast.makeText(getActivity(), R.string.xongroi, Toast.LENGTH_SHORT).show();
                        arrSinhVien.clear();
                        GetSinhVien();
                    }
                });
                builder.setNegativeButton(R.string.k, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //
                    }
                });
                builder.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void GetKhoa(){
        Cursor cursor1 = MainActivity.db.GetData("SELECT * FROM Khoa_Table");
        if(cursor1!=null){
            while (cursor1.moveToNext()){
                arrKhoa.add(new Khoa(cursor1.getString(0), cursor1.getString(1)));
            }
        }
    }
    private void GetSinhVien(){
        Cursor cursor = MainActivity.db.GetData("SELECT * FROM SinhVien_Table");
        if(cursor!=null){
            while (cursor.moveToNext()){
                arrSinhVien.add(new SinhVien(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getBlob(3), cursor.getString(4), cursor.getString(5), cursor.getString(6)));
            }
        }
        adapter = new SinhVienAdapter(getActivity(), R.layout.dong_sinh_vien, arrSinhVien);
        setListAdapter(adapter);
    }


    private void ShowFab(){
        fabBack.show();
        fabLogout.show();
        fabPlus.show();
    }
    private void HideFab(){
        fabPlus.hide();
        fabLogout.hide();
        fabBack.hide();
    }

    private void AnhXa(){
        animation = new AnimationUtils().loadAnimation(getActivity(), R.anim.zoom);
        sendSV = (SendSVDetail) getActivity();
        arrSinhVien = new ArrayList<>();
        arrKhoa = new ArrayList<>();
        fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fabBack = (FloatingActionButton) view.findViewById(R.id.fabBack);
        fabLogout = (FloatingActionButton) view.findViewById(R.id.fabLogout);
        fabPlus = (FloatingActionButton) view.findViewById(R.id.fabPlus);
    }

    private void XuLy(){
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(showhide == true){
                    HideFab();
                    showhide = false;
                }else{
                    ShowFab();
                    showhide = true;
                }
            }
        });
        fabLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                final SharedPreferences preferences = getActivity().getSharedPreferences("data_login", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("checked", false);
                editor.clear();
                editor.commit();
                //getActivity().finish();
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        fabBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
                Intent intent = new Intent(getActivity(), QuanLySinhVien.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });


        fabPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //getActivity().finish();
                //getActivity().getFragmentManager().popBackStack();
                Intent addSV = new Intent(getActivity(), ThemSinhVien.class);
                startActivity(addSV);
                getActivity().overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
            }
        });
    }


}
