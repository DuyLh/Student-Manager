package com.lehoangduy.quanlysinhvien.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.Adapter.KhoaAdapter;
import com.lehoangduy.quanlysinhvien.DanhSachSV;
import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.ktgiuaky.R;

import org.apache.commons.lang3.RandomStringUtils;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class UpdateSinhVien extends AppCompatActivity {

    Button btnUpdate, btnHuy;
    ImageView imgHinh;
    EditText edtTen, edtLop, edtChitiet;
    Spinner spnChonKhoa;
    ImageButton btnUp, btnCam;
    int REQUEST_CODE_HINH = 9999;
    int REQUEST_CODE_CHON_HINH = 1111;
    ArrayList<Khoa> mangKhoa;
    RadioGroup radioGroup;
    //RadioButton rdbNam, rdbNu;
    RadioButton rdbCheck;
    String masua = "";
    int vitri = 0;
    String masv = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_sinh_vien);
        AnhXa();
        setTitle(getString(R.string.sadfhgj));
        mangKhoa = new ArrayList<>();
        Intent intent = getIntent();
        Bundle getData = intent.getBundleExtra("data");
        masua = getData.getString("maupdate");
        imgHinh.setBackgroundResource(0);

        mangKhoa.add(new Khoa("", getString(R.string.chonlai)));
        GetKhoa();

        String khoa = "";
        String name = "";
        String gioitinh = "";
        String diachi = "";
        String lop = "";

        spnChonKhoa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                vitri = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Cursor cursor = MainActivity.db.GetData("SELECT * FROM SinhVien_Table WHERE MaSinhVien = '" + masua + "'");
        if (cursor != null) {
            while (cursor.moveToNext()) {
                masv = cursor.getString(0);
                name = cursor.getString(1);
                lop = cursor.getString(2);
                byte[] hinh = null;
                hinh = cursor.getBlob(3);
                Bitmap bitmap = BitmapFactory.decodeByteArray(hinh, 0, hinh.length);

                imgHinh.setImageBitmap(bitmap);
                gioitinh = cursor.getString(4);
                diachi = cursor.getString(5);
            }
        }
        edtTen.setText(name);
        edtChitiet.setText(diachi);
        if (gioitinh.toString().equals("Nam")) {
            radioGroup.check(R.id.radioButtonNam);
        } else {
            radioGroup.check(R.id.radioButtonNu);
        }
        edtLop.setText(lop);

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chon = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(chon, REQUEST_CODE_CHON_HINH);

            }
        });
        btnCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chup = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(chup, REQUEST_CODE_HINH);

            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtTen.getText().toString().equals("") || edtLop.getText().toString().equals("")){
                    Toast.makeText(UpdateSinhVien.this, R.string.havedasdsad,Toast.LENGTH_SHORT).show();
                }else{
                    if(imgHinh.getDrawable() == null){
                        Toast.makeText(UpdateSinhVien.this, R.string.dsadsadsadsa, Toast.LENGTH_SHORT).show();
                    }else{
                        String chuoi = RandomStringUtils.randomAlphanumeric(4).toUpperCase();
                        String chuoi1 = RandomStringUtils.randomAlphanumeric(3).toUpperCase();
                        String ma = "";
                        if(mangKhoa.get(vitri).MaKhoa.length() == 2){
                            ma = mangKhoa.get(vitri).MaKhoa+"00"+chuoi;
                        }else{
                            ma = mangKhoa.get(vitri).MaKhoa+"00"+chuoi1;
                        }
                        String ten = edtTen.getText().toString();
                        String lop = edtLop.getText().toString();
                        int IDGioiTinh = radioGroup.getCheckedRadioButtonId();
                        rdbCheck = (RadioButton) findViewById(IDGioiTinh);
                        String gioitinh = rdbCheck.getText().toString();
                        String chitiet = edtChitiet.getText().toString();

                        String makhoa = mangKhoa.get(vitri).MaKhoa;

                        MainActivity.db.UPDATE_SINHVIEN(ma, ten, lop, ImageView_To_Byte(imgHinh),gioitinh, chitiet, makhoa, masua);
                        Toast.makeText(UpdateSinhVien.this, R.string.fghjkl, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UpdateSinhVien.this, DanhSachSV.class);
                        startActivity(intent);
                        finish();

                    }
                }
            }
        });


    }

    private void AnhXa(){
        btnCam      = (ImageButton) findViewById(R.id.imageButtonCam);
        btnUp       = (ImageButton) findViewById(R.id.imageButtonUp);
        edtTen      = (EditText) findViewById(R.id.editTextTenSV);
        edtLop      = (EditText) findViewById(R.id.editTextLop);
        edtChitiet  = (EditText) findViewById(R.id.editTextChiTiet);
        imgHinh     = (ImageView) findViewById(R.id.imageViewHinh);
        btnUpdate   = (Button) findViewById(R.id.buttonUpdate);
        spnChonKhoa = (Spinner) findViewById(R.id.spinnerKhoa);
        radioGroup  = (RadioGroup) findViewById(R.id.radioGroup);
        btnHuy      = (Button) findViewById(R.id.buttonHuy);
    }


    public byte[] ImageView_To_Byte(ImageView imgv){

        BitmapDrawable drawable = (BitmapDrawable) imgv.getDrawable();
        Bitmap bmp = drawable.getBitmap();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_CODE_HINH && resultCode == RESULT_OK){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgHinh.setBackgroundResource(0);
            imgHinh.setImageBitmap(bitmap);
        }
        if(requestCode == REQUEST_CODE_CHON_HINH && resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            imgHinh.setBackgroundResource(0);
            imgHinh.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
    private void GetKhoa(){
        Cursor khoa = MainActivity.db.GetData("SELECT * FROM Khoa_Table");
        while (khoa.moveToNext()){
            mangKhoa.add(new Khoa(khoa.getString(0), khoa.getString(1)));
        }
        KhoaAdapter khoaadapter = new KhoaAdapter(this, R.layout.dong_khoa_spiner, mangKhoa);
        spnChonKhoa.setAdapter(khoaadapter);
    }
}
