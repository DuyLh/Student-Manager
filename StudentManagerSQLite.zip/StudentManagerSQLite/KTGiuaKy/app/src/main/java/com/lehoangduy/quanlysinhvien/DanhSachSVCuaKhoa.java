package com.lehoangduy.quanlysinhvien;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.lehoangduy.quanlysinhvien.Activity.ChiTietSinhVien;
import com.lehoangduy.quanlysinhvien.Activity.MainActivity;
import com.lehoangduy.quanlysinhvien.Adapter.SinhVienAdapter;
import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;

import java.util.ArrayList;

public class DanhSachSVCuaKhoa extends AppCompatActivity {

    ListView lvDSSVKhoa;
    ArrayList<SinhVien> arrayList;
    String maIntent = "";
    FloatingActionButton fbBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_svcua_khoa);
        lvDSSVKhoa = (ListView) findViewById(R.id.lvSinhVienofKhoa);
        arrayList = new ArrayList<>();
        fbBack = (FloatingActionButton) findViewById(R.id.fbBack);

        Intent getIntent = getIntent();
        maIntent = getIntent.getStringExtra("masvofkhoa");

        lvDSSVKhoa.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(DanhSachSVCuaKhoa.this, ChiTietSinhVien.class);
                intent.putExtra("masv", arrayList.get(position).MaSinhVien);
                startActivity(intent);
            }
        });

        Cursor svoKhoa = MainActivity.db.GetData("SELECT * FROM SinhVien_Table WHERE MaKhoa = '"+maIntent+"'");
        if(svoKhoa!=null){
            while (svoKhoa.moveToNext()){
                arrayList.add(new SinhVien(svoKhoa.getString(0), svoKhoa.getString(1), svoKhoa.getString(2), svoKhoa.getBlob(3), svoKhoa.getString(4), svoKhoa.getString(5), svoKhoa.getString(6)));
            }
        }
        SinhVienAdapter adapter = new SinhVienAdapter(getApplicationContext(), R.layout.dong_sinh_vien, arrayList);
        lvDSSVKhoa.setAdapter(adapter);

        fbBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DanhSachSVCuaKhoa.this, DanhSachKhoa.class);
                startActivity(intent);
            }
        });
    }
}
