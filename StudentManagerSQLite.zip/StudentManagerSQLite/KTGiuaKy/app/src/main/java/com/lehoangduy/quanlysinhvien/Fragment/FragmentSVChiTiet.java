package com.lehoangduy.quanlysinhvien.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;

/**
 * Created by Admin on 11/24/2016.
 */

public class FragmentSVChiTiet extends Fragment {
    TextView txtTen, txtMa, txtLop, txtDiaChi, txtGioiTinh;
    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_sv_chitiet, container, false);
        AnhXa();
        return view;
    }

    public void SetText(SinhVien sinhVien){
        txtTen.setText(sinhVien.TenSinhVien);
        txtMa.setText("MSSV: "+sinhVien.MaSinhVien);
        txtLop.setText("Lớp: "+sinhVien.Lop);
        txtGioiTinh.setText("Giới tính: "+ sinhVien.GioiTinh);
        txtDiaChi.setText("Địa chỉ: "+sinhVien.ChiTietSV);
    }

    private void AnhXa(){
        txtTen = (TextView) view.findViewById(R.id.txtHoTenFragment);
        txtMa = (TextView) view.findViewById(R.id.txtMSSVFragment);
        txtLop = (TextView) view.findViewById(R.id.txtLopFragment);
        txtDiaChi = (TextView) view.findViewById(R.id.txtDiaChiFragment);
        txtGioiTinh = (TextView) view.findViewById(R.id.txtGTFragment);
    }
}
