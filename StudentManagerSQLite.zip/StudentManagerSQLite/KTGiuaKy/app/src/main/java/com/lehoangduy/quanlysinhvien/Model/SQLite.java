package com.lehoangduy.quanlysinhvien.Model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

/**
 * Created by Administrator on 10/3/2016.
 */

public class SQLite extends SQLiteOpenHelper {
    public SQLite(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    public void QueryData(String sql){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(sql);
    }

    public void INSERT_SINHVIEN(String MaSinhVien, String TenSinhVien, String Lop, byte[] HinhAnh, String GioiTinh,  String ChiTiet, String MaKhoa ){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "INSERT INTO SinhVien_Table VALUES(?, ?, ?, ?, ?, ?, ?)";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaSinhVien);
        statement.bindString(2, TenSinhVien);
        statement.bindString(3, Lop);
        statement.bindBlob(4, HinhAnh);
        statement.bindString(5, GioiTinh);
        statement.bindString(6, ChiTiet);
        statement.bindString(7, MaKhoa);
        statement.executeInsert(); // thực hiện lệnh insert
    }

    public void UPDATE_SINHVIEN(String MaSinhVien, String TenSinhVien, String Lop, byte[] HinhAnh, String GioiTinh,  String ChiTiet, String MaKhoa, String IDSV ){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "UPDATE SinhVien_Table SET MaSinhVien =?, TenSinhVien =?, Lop =?, HinhAnh =?, GioiTinh =?, ChiTiet =?, MaKhoa = ? WHERE MaSinhVien =?";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaSinhVien);
        statement.bindString(2, TenSinhVien);
        statement.bindString(3, Lop);
        statement.bindBlob(4, HinhAnh);
        statement.bindString(5, GioiTinh);
        statement.bindString(6, ChiTiet);
        statement.bindString(7, MaKhoa);
        statement.bindString(8, IDSV);
        statement.executeUpdateDelete();
    }

    public void DELETE_SINHVIEN(String MaSinhVien){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "DELETE FROM SinhVien_Table WHERE MaSinhVien = ?";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaSinhVien);
        statement.executeUpdateDelete();
    }
    public void DELETE_SINHVIEN_FROM_KHOA(String MaKhoa){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "DELETE FROM SinhVien_Table WHERE MaKhoa = ?";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(7, MaKhoa);
        statement.executeUpdateDelete();
    }

    public void INSERT_KHOA(String MaKhoa, String TenKhoa){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "INSERT INTO Khoa_Table VALUES(?, ?)";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaKhoa);
        statement.bindString(2, TenKhoa);
        statement.executeInsert();
    }


    public void DELETE_KHOA(String MaKhoa){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "DELETE FROM Khoa_Table WHERE MaKhoa = ?";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaKhoa);
        statement.executeUpdateDelete();
    }
    public void UPDATE_KHOA(String MaKhoa, String TenKhoa, String ID){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "UPDATE Khoa_Table SET MaKhoa = ?, TenKhoa = ? WHERE MaKhoa = ?";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, MaKhoa);
        statement.bindString(2, TenKhoa);
        statement.bindString(3, ID);
        statement.executeUpdateDelete();
    }
    public Cursor GetData(String sql){
        SQLiteDatabase db = getWritableDatabase();
        return db.rawQuery(sql, null);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
