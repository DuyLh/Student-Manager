package com.lehoangduy.quanlysinhvien.Model;

/**
 * Created by Admin on 10/10/2016.
 */

public class SinhVien {
    public String MaSinhVien;
    public String TenSinhVien;
    public String Lop;
    public byte[] HinhAnh;
    public String GioiTinh;
    public String ChiTietSV;
    public String MaKhoa;


    public SinhVien() {
    }

    public SinhVien(String maSinhVien, String tenSinhVien, String lop, byte[] hinhAnh, String gioiTinh, String chiTietSV, String maKhoa) {
        MaSinhVien = maSinhVien;
        TenSinhVien = tenSinhVien;
        Lop = lop;
        HinhAnh = hinhAnh;
        GioiTinh = gioiTinh;
        ChiTietSV = chiTietSV;
        MaKhoa = maKhoa;
    }
}


