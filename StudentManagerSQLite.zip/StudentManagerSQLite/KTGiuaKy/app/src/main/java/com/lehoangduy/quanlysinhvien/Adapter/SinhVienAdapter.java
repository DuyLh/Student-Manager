package com.lehoangduy.quanlysinhvien.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.lehoangduy.quanlysinhvien.Model.SinhVien;
import com.lehoangduy.ktgiuaky.R;

import java.util.List;

/**
 * Created by Admin on 10/10/2016.
 */

public class SinhVienAdapter extends ArrayAdapter<SinhVien> {

    public SinhVienAdapter(Context context, int resource, List<SinhVien> items) {
        super(context, resource, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            view =  inflater.inflate(R.layout.dong_sinh_vien, null);
        }
      //  view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.2f));
        if(position%2!=0){
            view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.2f));
        }else {
            view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.1f));
        }
        SinhVien p = getItem(position);
        if (p != null) {
            // Anh xa + Gan gia tri
            TextView txtTen = (TextView) view.findViewById(R.id.textViewTen);
            TextView txtlop = (TextView) view.findViewById(R.id.textViewLop);
            TextView txtGioiTinh = (TextView) view.findViewById(R.id.textViewGioiTinh);
            ImageView imgHinh = (ImageView) view.findViewById(R.id.imageViewSV);

            txtTen.setText(p.TenSinhVien);
            txtlop.setText("MSSV: "+p.MaSinhVien);
            txtGioiTinh.setText("Giới tính: "+p.GioiTinh);

            byte[] hinhanh = p.HinhAnh;
            Bitmap bitmap = BitmapFactory.decodeByteArray(hinhanh, 0, hinhanh.length);
            imgHinh.setImageBitmap(bitmap);

        }
        return view;
    }

    public static int getColorWithAlpha(int color, float ratio) {
        int newColor = 0;
        int alpha = Math.round(Color.alpha(color) * ratio);
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        newColor = Color.argb(alpha, r, g, b);
        return newColor;
    }

}
