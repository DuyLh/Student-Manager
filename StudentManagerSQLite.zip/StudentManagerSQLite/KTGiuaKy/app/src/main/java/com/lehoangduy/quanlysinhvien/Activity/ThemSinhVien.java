package com.lehoangduy.quanlysinhvien.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.Adapter.KhoaAdapter;
import com.lehoangduy.quanlysinhvien.DanhSachSV;
import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.ktgiuaky.R;

import org.apache.commons.lang3.RandomStringUtils;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class ThemSinhVien extends AppCompatActivity {

    Button btnThem, btnHuy;
    ImageView imgHinh;
    EditText edtTen, edtLop, edtChitiet;
    Spinner spnChonKhoa;
    ImageButton btnUp, btnCam;
    int REQUEST_CODE_HINH = 9999;
    int REQUEST_CODE_CHON_HINH = 1111;
    ArrayList<Khoa> mangKhoa;
    RadioGroup radioGroup;
    //RadioButton rdbNam, rdbNu;
    RadioButton rdbCheck;
    int vitri = 1;
    String masua = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them_sinh_vien);

        AnhXa();

        mangKhoa = new ArrayList<>();

        Intent suaSV = getIntent();
        masua = suaSV.getStringExtra("sua");


        mangKhoa.add(new Khoa("", getString(R.string.choose)));
        Cursor khoa = MainActivity.db.GetData("SELECT * FROM Khoa_Table");
        while (khoa.moveToNext()){
            mangKhoa.add(new Khoa(khoa.getString(0), khoa.getString(1)));
        }
        KhoaAdapter khoaadapter = new KhoaAdapter(this, R.layout.dong_khoa_spiner, mangKhoa);
        spnChonKhoa.setAdapter(khoaadapter);

        imgHinh.setBackgroundResource(R.drawable.img);

        spnChonKhoa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                vitri = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view.startAnimation(MainActivity.alphaAnimation);
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_CHON_HINH);
            }
        });
        btnCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view.startAnimation(MainActivity.alphaAnimation);
                Intent chup = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(chup, REQUEST_CODE_HINH);

            }
        });
        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(MainActivity.alphaAnimation);
                finish();
            }
        });
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view.startAnimation(MainActivity.alphaAnimation);
                if(edtTen.getText().toString().equals("") || edtLop.getText().toString().equals("")){
                    Toast.makeText(ThemSinhVien.this, R.string.chuanhapdutt,Toast.LENGTH_SHORT).show();
                }else{
                    if(imgHinh.getDrawable() == null){
                        Toast.makeText(ThemSinhVien.this, R.string.chuacohinh, Toast.LENGTH_SHORT).show();
                    }else{
                        String chuoi = RandomStringUtils.randomAlphanumeric(4).toUpperCase();
                        String chuoi1 = RandomStringUtils.randomAlphanumeric(3).toUpperCase();
                        String ma = "";
                        if(mangKhoa.get(vitri).MaKhoa.length() == 2){
                            ma = mangKhoa.get(vitri).MaKhoa+"00"+chuoi;
                        }else{
                            ma = mangKhoa.get(vitri).MaKhoa+"00"+chuoi1;
                        }
                        String ten = edtTen.getText().toString();
                        String lop = edtLop.getText().toString();
                        int IDGioiTinh = radioGroup.getCheckedRadioButtonId();
                        rdbCheck = (RadioButton) findViewById(IDGioiTinh);
                        String gioitinh = rdbCheck.getText().toString();
                        String chitiet = edtChitiet.getText().toString();

                        String makhoa = mangKhoa.get(vitri).MaKhoa;

                        MainActivity.db.INSERT_SINHVIEN(ma, ten, lop, ImageView_To_Byte(imgHinh),gioitinh, chitiet, makhoa);
                        Toast.makeText(ThemSinhVien.this, R.string.dathemmoi, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ThemSinhVien.this, DanhSachSV.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        });

    }


    private void AnhXa(){
        btnHuy      = (Button) findViewById(R.id.buttonHuy);
        btnCam      = (ImageButton) findViewById(R.id.imageButtonCam);
        btnUp       = (ImageButton) findViewById(R.id.imageButtonUp);
        edtTen      = (EditText) findViewById(R.id.editTextTenSV);
        edtLop      = (EditText) findViewById(R.id.editTextLop);
        edtChitiet  = (EditText) findViewById(R.id.editTextChiTiet);
        imgHinh     = (ImageView) findViewById(R.id.imageViewHinh);
        btnThem     = (Button) findViewById(R.id.buttonThem);
        spnChonKhoa = (Spinner) findViewById(R.id.spinnerKhoa);
        radioGroup  = (RadioGroup) findViewById(R.id.radioGroup);
    }

    public byte[] ImageView_To_Byte(ImageView imgv){

        BitmapDrawable drawable = (BitmapDrawable) imgv.getDrawable();
        Bitmap bmp = drawable.getBitmap();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_CODE_HINH && resultCode == RESULT_OK){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgHinh.setBackgroundResource(0);
            imgHinh.setImageBitmap(bitmap);
        }
        if(requestCode == REQUEST_CODE_CHON_HINH && resultCode == RESULT_OK && data != null){
            Uri uri = data.getData();
            try {
                InputStream input = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                imgHinh.setBackgroundResource(0);
                imgHinh.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

}
