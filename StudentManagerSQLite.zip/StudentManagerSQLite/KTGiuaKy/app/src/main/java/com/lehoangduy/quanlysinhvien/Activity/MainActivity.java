package com.lehoangduy.quanlysinhvien.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.Model.SQLite;
import com.lehoangduy.ktgiuaky.R;

public class MainActivity extends AppCompatActivity {

    Button btnDangNhap, btnClear;
    EditText edtUser, edtPass;
    CheckBox ckRemember;
    public static SQLite db;
    public static AlphaAnimation alphaAnimation;
    private Boolean exit = false;
    TextInputLayout inputText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alphaAnimation = new AlphaAnimation(1F, 0.5F);

        if (getIntent().getBooleanExtra("EXIT", false)) {
            finish();
        }

        setTitle(getString(R.string.sdfgh));

        AnhXa();

        final SharedPreferences preferences = getSharedPreferences("data_login", MODE_PRIVATE);
        edtUser.setText(preferences.getString("username", ""));
        edtPass.setText(preferences.getString("password", ""));
        ckRemember.setChecked(preferences.getBoolean("checked", false));
        final Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.effect);
        final Animation animation = AnimationUtils.loadAnimation(this, R.anim.zoom);
        btnDangNhap.setAnimation(animation);
        btnClear.setAnimation(animation);

        db = new SQLite(this, "qlsinhvien.sqlite", null, 1);

        db.QueryData("CREATE TABLE IF NOT EXISTS Khoa_Table(MaKhoa VARCHAR PRIMARY KEY, TenKhoa NVARCHAR)");

        db.QueryData("CREATE TABLE IF NOT EXISTS SinhVien_Table(MaSinhVien VARCHAR PRIMARY KEY, TenSinhVien NVARCHAR, Lop VARCHAR, HinhAnh BLOB, GioiTinh NVARCHAR, ChiTiet NVARCHAR, MaKhoa VARCHAR CONSTRAINT fk_Khoa_SinhVien REFERENCES Khoa_Table(MaKhoa))");

//        db.QueryData("INSERT INTO Khoa_Table VALUES('TH', 'Công Nghệ Thông Tin')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('TP', 'Công Nghệ Thực Phẩm')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('QT', 'Quản trị kinh doanh')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('CDT', 'Cơ Điện Tử')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('DDT', 'Điện Điện Tử')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('TK', 'Design')");
//        db.QueryData("INSERT INTO Khoa_Table VALUES('XD', 'Kỹ Thuật Công Trình')");

        btnDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtUser.getText().toString();
                String pass = edtPass.getText().toString();
                view.startAnimation(alphaAnimation);
                if(name.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, R.string.chuanhap, Toast.LENGTH_SHORT).show();
                }else {
                    if (name.equals("manager") && pass.equals("123")) {
                        if(ckRemember.isChecked()){
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("username", name);
                            editor.putString("password", pass);
                            editor.putBoolean("checked", true);
                            editor.commit();
                        }else {
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("username", "");
                            editor.putString("password", "");
                            editor.putBoolean("checked", false);
                            editor.commit();
                        }
                        Toast.makeText(MainActivity.this, R.string.loginthnahcong, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, QuanLySinhVien.class);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);// | Intent.FLAG_ACTIVITY_NEW_TASK);

                        startActivity(intent);
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                        edtPass.setText("");
                    } else {
                        Toast.makeText(MainActivity.this, R.string.saitendangnhap, Toast.LENGTH_SHORT).show();
                        inputText.setAnimation(animation1);
                        edtPass.setText("");
                    }
                }
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtPass.setText("");
                edtUser.setText("");
                v.startAnimation(alphaAnimation);
            }
        });

    }

    @Override
    public void onBackPressed() {
        if (exit) {
            finish();
        } else {
            Toast.makeText(this, R.string.anback, Toast.LENGTH_SHORT).show();
            exit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, 3 * 1000);

        }
    }

    private void AnhXa(){
        btnDangNhap = (Button) findViewById(R.id.btnDangNhap);
        edtPass     = (EditText) findViewById(R.id.edtPass);
        edtUser     = (EditText) findViewById(R.id.edtUser);
        ckRemember  = (CheckBox) findViewById(R.id.ckRemenber);
        btnClear    = (Button) findViewById(R.id.btnClear);
        inputText   = (TextInputLayout) findViewById(R.id.inputText);
    }
}
