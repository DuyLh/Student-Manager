package com.lehoangduy.quanlysinhvien.Model;

/**
 * Created by Admin on 10/20/2016.
 */

public class Khoa {
    public String MaKhoa;
    public String TenKhoa;

    public Khoa() {
    }

    public Khoa(String maKhoa, String tenKhoa) {
        MaKhoa = maKhoa;
        TenKhoa = tenKhoa;
    }
}
