package com.lehoangduy.quanlysinhvien.Fragment;

import com.lehoangduy.quanlysinhvien.Model.SinhVien;

/**
 * Created by Admin on 11/24/2016.
 */

public interface SendSVDetail {
    public void NhanSV(SinhVien sv);
}
