package com.lehoangduy.quanlysinhvien.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.lehoangduy.quanlysinhvien.DanhSachKhoa;
import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.ktgiuaky.R;

import java.util.ArrayList;

public class ThemKhoa extends AppCompatActivity {

    Button btnAdd, btnCal, btnUp;
    EditText edtName, edtCode;
    String ID = "";
    ArrayList<Khoa> mangKhoa;
    ArrayList<Khoa> arrKhoa;
    String maCheck = "";
    String tenCheck = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them_khoa);
        setFinishOnTouchOutside(false);
        addControl();

        final Intent intent = getIntent();
        ID = intent.getStringExtra("makhoa");
        final String name = edtName.getText().toString();


        Cursor state = MainActivity.db.GetData("SELECT * FROM Khoa_Table WHERE MaKhoa = '"+ID+"'");
        if (state!=null){
            while (state.moveToNext()){
                mangKhoa.add(new Khoa(state.getString(0), state.getString(1)));
            }
            if(mangKhoa.size()>0){
                edtCode.setEnabled(false);
                btnUp.setEnabled(true);
                btnAdd.setEnabled(false);
            }
        }
        mangKhoa.clear();

        Cursor update = MainActivity.db.GetData("SELECT * FROM Khoa_Table WHERE MaKhoa = '"+ID+"'");
        if(update!=null){
            while (update.moveToNext()){
                String ma = update.getString(0);
                String ten = update.getString(1);
                edtCode.setText(ma);
                edtName.setText(ten);
            }
        }

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    KiemTra();
                    if (mangKhoa.size() > 0) {
                        mangKhoa.clear();
                        Toast.makeText(ThemKhoa.this, R.string.datontaikhoanay, Toast.LENGTH_SHORT).show();
                    } else {
                        if(edtCode.getText().toString().equals("") || edtName.getText().toString().equals("")){
                            Toast.makeText(ThemKhoa.this, R.string.chuanhapdu, Toast.LENGTH_SHORT).show();
                        }else{
                            maCheck = edtCode.getText().toString().toUpperCase();
                            tenCheck = edtName.getText().toString();
                            MainActivity.db.INSERT_KHOA(maCheck, tenCheck);
                            Toast.makeText(getApplicationContext(), R.string.dathem, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ThemKhoa.this, DanhSachKhoa.class);
                            startActivity(intent);
                        }
                }

            }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newName = edtName.getText().toString();
                MainActivity.db.UPDATE_KHOA(ID, newName, ID);
                Toast.makeText(getApplicationContext(), R.string.dacapnhat, Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(ThemKhoa.this, DanhSachKhoa.class);
                startActivity(intent1);



            }
        });
    }


    private void KiemTra() {
        maCheck = edtCode.getText().toString();
        Cursor kt = MainActivity.db.GetData("SELECT * FROM Khoa_Table WHERE MaKhoa = '" + maCheck + "'");
        if (kt != null) {
            while (kt.moveToNext()) {
                mangKhoa.add(new Khoa(kt.getString(0), kt.getString(1)));
            }
        }
    }


    private void addControl(){
        arrKhoa = new ArrayList<>();
        mangKhoa = new ArrayList<>();
        btnUp = (Button) findViewById(R.id.buttonUpdate);
        btnAdd = (Button) findViewById(R.id.buttonAddKhoa);
        btnCal = (Button) findViewById(R.id.buttonCancel);
        edtName = (EditText) findViewById(R.id.editTextTenKhoaThem);
        edtCode = (EditText) findViewById(R.id.editTextMaKhoaThem);
    }
}
