package com.lehoangduy.quanlysinhvien.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.lehoangduy.ktgiuaky.R;
import com.lehoangduy.quanlysinhvien.DanhSachSV;
import com.lehoangduy.quanlysinhvien.Model.SinhVien;

import java.util.ArrayList;

public class ChiTietSinhVien extends AppCompatActivity {

    TextView txtTen, txtLop, txtMSSV, txtGioiTinh, txtKhoa, txtDiaChi;
    ImageView imgHinh;
    ImageButton btnBack, btnDelete, btnUpdate;
    String masv = "";
    String name = "";
    String gioitinh = "";
    String diachi = "";
    String lop = "";
    String khoa = "";
    String mact = "";
    String makhoa = "";
    ArrayList<SinhVien> arrSinhVien;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_sinh_vien);

        addControl();

        Intent intent = getIntent();
        mact = intent.getStringExtra("masv");
        GetSinhVienCT();

        GetKhoaCT();

        txtMSSV.setText(masv);
        txtTen.setText(name);
        txtDiaChi.setText(diachi);
        txtGioiTinh.setText(gioitinh);
        txtKhoa.setText(khoa);
        txtLop.setText(lop);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ChiTietSinhVien.this);
                builder.setTitle(R.string.xachanxoasv);
                builder.setIcon(R.mipmap.ic_launcher_delete);
                builder.setMessage(R.string.xoanha);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.c, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.db.DELETE_SINHVIEN(mact);
                        Toast.makeText(ChiTietSinhVien.this, R.string.xongroi, Toast.LENGTH_SHORT).show();
                        Intent intent1 = new Intent(ChiTietSinhVien.this, DanhSachSV.class);
                        startActivity(intent1);
                        finish();
                    }
                });
                builder.setNegativeButton(R.string.k, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //
                    }
                });
                builder.show();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChiTietSinhVien.this, UpdateSinhVien.class);
                Bundle bundle = new Bundle();
                bundle.putString("maKhoa", arrSinhVien.get(0).MaKhoa);
                bundle.putString("maupdate", arrSinhVien.get(0).MaSinhVien);
                intent.putExtra("data", bundle);
                startActivity(intent);
                finish();
            }
        });
    }

    private void GetKhoaCT(){
        Cursor cursor1 = MainActivity.db.GetData("SELECT * FROM Khoa_Table WHERE MaKhoa = '"+makhoa+"'");
        if(cursor1!=null){
            while (cursor1.moveToNext()){
                khoa = cursor1.getString(1);
            }
        }
    }

    private void GetSinhVienCT(){
        Cursor cursor = MainActivity.db.GetData("SELECT * FROM SinhVien_Table WHERE MaSinhVien = '"+mact+"'");
        if(cursor!=null) {
            while (cursor.moveToNext()) {
                masv = cursor.getString(0);
                name = cursor.getString(1);
                lop = cursor.getString(2);
                byte[] hinh = null;
                hinh = cursor.getBlob(3);
                Bitmap bitmap = BitmapFactory.decodeByteArray(hinh, 0, hinh.length);
                imgHinh.setImageBitmap(bitmap);
                gioitinh = cursor.getString(4);
                diachi = cursor.getString(5);
                makhoa = cursor.getString(6);
                arrSinhVien.add(new SinhVien(masv, name, lop, hinh, gioitinh, diachi, makhoa));
            }
        }
    }

    private void addControl(){
        arrSinhVien  = new ArrayList<>();
        btnUpdate    = (ImageButton) findViewById(R.id.imageButtonEditCT);
        btnDelete    = (ImageButton) findViewById(R.id.imageButtonDeleteCT);
        btnBack      = (ImageButton) findViewById(R.id.imageButtonBackCT);
        imgHinh      = (ImageView) findViewById(R.id.imageViewHinhChiTiet);
        txtTen       = (TextView) findViewById(R.id.textViewHoTenChiTiet);
        txtLop       = (TextView) findViewById(R.id.TextViewLopChiTiet);
        txtMSSV      = (TextView) findViewById(R.id.TexviewMSSVChiTiet);
        txtGioiTinh  = (TextView) findViewById(R.id.TexviewGioiTinhChiTiet);
        txtKhoa      = (TextView) findViewById(R.id.textViewKhoaChiTiet);
        txtDiaChi    = (TextView) findViewById(R.id.TexviewDiaChiChiTiet);
    }
}
