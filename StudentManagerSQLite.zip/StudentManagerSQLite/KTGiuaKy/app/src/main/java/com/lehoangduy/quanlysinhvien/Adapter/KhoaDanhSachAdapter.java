package com.lehoangduy.quanlysinhvien.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.lehoangduy.quanlysinhvien.Model.Khoa;
import com.lehoangduy.ktgiuaky.R;

import java.util.List;

/**
 * Created by Admin on 10/23/2016.
 */

public class KhoaDanhSachAdapter extends ArrayAdapter<Khoa> {

    List<Khoa> arrKhoa;

    public KhoaDanhSachAdapter(Context context, int resource, List<Khoa> items) {
        super(context, resource, items);
        arrKhoa = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            view =  inflater.inflate(R.layout.dong_khoa, null);
        }
//        view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.7f));
        if(position%2!=0){
            view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.1f));
        }else {
            view.setBackgroundColor(getColorWithAlpha(Color.WHITE, 0.2f));
        }
        Khoa p = getItem(position);
        if (p != null) {
            // Anh xa + Gan gia tri
            TextView txtTen = (TextView) view.findViewById(R.id.textViewTenKhoaAdapter);
            TextView txtMa = (TextView) view.findViewById(R.id.textViewMaKhoaAdapter);
            txtMa.setText("Mã khoa: "+p.MaKhoa);
            txtTen.setText(p.TenKhoa);
        }
        return view;
    }
    public static int getColorWithAlpha(int color, float ratio) {
        int newColor = 0;
        int alpha = Math.round(Color.alpha(color) * ratio);
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        newColor = Color.argb(alpha, r, g, b);
        return newColor;
    }

}
